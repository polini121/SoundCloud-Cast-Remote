// Offscreen document: hostuje właściwe połączenie PeerJS. Ma prawdziwe
// window/DOM, więc WebRTC działa (czego brakuje w background.js jako
// service workerze). Nie ma dostępu do chrome.tabs, więc komendy do karty
// SoundCloud wysyła przez background.js (typ "relay_sc").

let peer = null;
let currentConn = null;
let peerId = null;
let lastInfo = null;

async function getStoredId() {
  const resp = await chrome.runtime.sendMessage({ type: "relay_storage_get", key: "peerId" });
  return resp?.value;
}

async function saveId(id) {
  await chrome.runtime.sendMessage({ type: "relay_storage_set", data: { peerId: id } });
}

function randomId() {
  // Krótki, czytelny kod (małe litery, żeby uniknąć problemów z wielkością liter
  // przy wpisywaniu na telefonie - PeerJS rozróżnia wielkość liter w ID).
  const chars = "abcdefghjklmnpqrstuvwxyz23456789";
  let s = "sc-";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function setStatus(status, extra = {}) {
  chrome.runtime.sendMessage({ type: "relay_storage_set", data: { status, ...extra } }).catch(() => {});
}

function sendToSoundcloud(payload) {
  return chrome.runtime.sendMessage({ type: "relay_sc", payload });
}

function setupConnection(conn) {
  currentConn = conn;
  conn.on("open", () => {
    conn.send({ type: "hello", info: lastInfo });
    chrome.runtime.sendMessage({ type: "relay_storage_set", data: { connected: true } }).catch(() => {});
  });
  conn.on("data", async (data) => {
    if (!data || !data.type) return;
    if (data.type === "action") {
      const res = await sendToSoundcloud({ type: "sc_action", action: data.action, value: data.value });
      if (res?.info) lastInfo = res.info;
      conn.send({ type: "state", info: lastInfo, ok: res?.ok, error: res?.error });
    } else if (data.type === "get") {
      const res = await sendToSoundcloud({ type: "sc_info" });
      if (res?.info) lastInfo = res.info;
      conn.send({ type: "state", info: lastInfo, ok: res?.ok, error: res?.error });
    }
  });
  conn.on("close", () => {
    if (currentConn === conn) currentConn = null;
    chrome.runtime.sendMessage({ type: "relay_storage_set", data: { connected: false } }).catch(() => {});
  });
}

async function initPeer() {
  if (peer && !peer.destroyed) return peerId;
  let id = await getStoredId();
  if (!id) {
    id = randomId();
    await saveId(id);
  }
  peerId = id;

  // eslint-disable-next-line no-undef
  peer = new Peer(id, { debug: 1 });
  peer.on("open", (openId) => {
    peerId = openId;
    setStatus("online", { peerId: openId });
  });
  peer.on("connection", (conn) => setupConnection(conn));
  peer.on("disconnected", () => {
    setStatus("disconnected");
    try { peer.reconnect(); } catch (e) {}
  });
  peer.on("error", async (err) => {
    console.warn("Peer error", err?.type, err?.message);
    setStatus("error", { statusMsg: String(err?.type || err?.message || err) });
    if (err?.type === "unavailable-id") {
      // ID zajęte, wygeneruj nowe
      const newId = randomId();
      await saveId(newId);
      peer.destroy();
      peer = null;
      setTimeout(initPeer, 500);
    }
  });
  return id;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "os_sc_update") {
    lastInfo = msg.info;
    if (currentConn && currentConn.open) {
      try { currentConn.send({ type: "state", info: lastInfo }); } catch (e) {}
    }
    return false;
  }
  if (msg?.type === "os_get_status") {
    initPeer().then((id) => sendResponse({ peerId: id, connected: !!(currentConn && currentConn.open) }));
    return true;
  }
  if (msg?.type === "os_regen") {
    (async () => {
      const id = randomId();
      await saveId(id);
      if (peer) { try { peer.destroy(); } catch (e) {} }
      peer = null;
      const newId = await initPeer();
      sendResponse({ peerId: newId });
    })();
    return true;
  }
});

initPeer();
