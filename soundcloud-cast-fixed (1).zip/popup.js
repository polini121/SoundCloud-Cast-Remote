const REMOTE_BASE = "https://polini121.github.io/SoundCloud-Cast-Remote";

const codeEl = document.getElementById("code");
const urlEl = document.getElementById("url");
const statusEl = document.getElementById("status");

function render(id, connected) {
  codeEl.textContent = id || "…";
  const url = `${REMOTE_BASE}/?id=${encodeURIComponent(id || "")}`;
  urlEl.textContent = url;
  statusEl.textContent = connected ? "Telefon połączony ✓" : "Oczekiwanie na telefon…";
  statusEl.className = "status " + (connected ? "ok" : "warn");
}

function refresh() {
  chrome.runtime.sendMessage({ type: "popup_get" }, (resp) => {
    if (resp) render(resp.peerId, resp.connected);
  });
}

document.getElementById("copy").addEventListener("click", () => {
  navigator.clipboard.writeText(urlEl.textContent);
});
document.getElementById("regen").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "popup_regen" }, (resp) => {
    if (resp) render(resp.peerId, false);
  });
});

refresh();
setInterval(refresh, 1500);
