// Service worker: NIE hostuje już PeerJS (service workery w MV3 nie mają
// dostępu do RTCPeerConnection/WebRTC - stąd błąd "does not support WebRTC").
// Zamiast tego utrzymuje dokument offscreen (offscreen.html/offscreen.js),
// który ma prawdziwe okno DOM i pełne wsparcie WebRTC. Ten plik pełni rolę
// łącznika: przekazuje polecenia do karty SoundCloud (do czego offscreen
// document nie ma dostępu) i pośredniczy w komunikacji popup <-> offscreen.

const OFFSCREEN_URL = "offscreen.html";

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)],
  });
  return contexts.length > 0;
}

let creatingOffscreen = null;
async function ensureOffscreen() {
  if (await hasOffscreenDocument()) return;
  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ["WEB_RTC"],
    justification: "Utrzymuje połączenie PeerJS (WebRTC) do zdalnego sterowania SoundCloud.",
  });
  try {
    await creatingOffscreen;
  } finally {
    creatingOffscreen = null;
  }
}

async function findSoundcloudTab() {
  const tabs = await chrome.tabs.query({ url: ["https://soundcloud.com/*", "https://*.soundcloud.com/*"] });
  // Prefer active audible tab
  tabs.sort((a, b) => (b.audible ? 1 : 0) - (a.audible ? 1 : 0));
  return tabs[0] || null;
}

async function sendToSoundcloud(payload) {
  const tab = await findSoundcloudTab();
  if (!tab) return { ok: false, error: "Nie znaleziono karty SoundCloud. Otwórz soundcloud.com" };
  try {
    const res = await chrome.tabs.sendMessage(tab.id, payload);
    return res || { ok: true };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "relay_sc") {
    // Prośba od offscreen document, żeby wysłać komendę do karty SoundCloud
    // (offscreen document nie ma dostępu do chrome.tabs).
    sendToSoundcloud(msg.payload).then(sendResponse);
    return true;
  }
  if (msg?.type === "relay_storage_get") {
    // offscreen document nie ma dostępu do chrome.storage - odczyt robi za nie background.
    chrome.storage.local.get(msg.key).then((res) => sendResponse({ value: res[msg.key] }));
    return true;
  }
  if (msg?.type === "relay_storage_set") {
    chrome.storage.local.set(msg.data).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "sc_update") {
    // Info z content.js -> przekaż do offscreen document, żeby zaktualizować
    // stan wysyłany do telefonu.
    ensureOffscreen().then(() => {
      chrome.runtime.sendMessage({ type: "os_sc_update", info: msg.info }).catch(() => {});
    });
    return false;
  }
  if (msg?.type === "popup_get") {
    ensureOffscreen()
      .then(() => chrome.runtime.sendMessage({ type: "os_get_status" }))
      .then((resp) => sendResponse(resp))
      .catch(() => sendResponse({ peerId: null, connected: false }));
    return true;
  }
  if (msg?.type === "popup_regen") {
    ensureOffscreen()
      .then(() => chrome.runtime.sendMessage({ type: "os_regen" }))
      .then((resp) => sendResponse(resp))
      .catch(() => sendResponse({ peerId: null }));
    return true;
  }
});

chrome.runtime.onStartup.addListener(() => ensureOffscreen());
chrome.runtime.onInstalled.addListener(() => ensureOffscreen());
ensureOffscreen();
