// Runs on soundcloud.com. Receives commands from background.js and controls playback.
(function () {
  "use strict";

  const q = (sel) => document.querySelector(sel);

  function click(sel) {
    const el = q(sel);
    if (el) {
      el.click();
      return true;
    }
    return false;
  }

  function isPlaying() {
    const btn = q(".playControls__play");
    if (!btn) return false;
    return btn.classList.contains("playing") || btn.getAttribute("title")?.toLowerCase().includes("pause");
  }

  // SoundCloud oznacza aktywne przyciski-przełączniki (like/shuffle/repeat/mute)
  // przez aria-pressed="true" albo klasę sc-button-selected - sprawdzamy oba warianty.
  function isToggled(el) {
    if (!el) return false;
    return (
      el.getAttribute("aria-pressed") === "true" ||
      el.classList.contains("sc-button-selected") ||
      el.classList.contains("selected")
    );
  }

  function getTrackInfo() {
    const title = q(".playbackSoundBadge__titleLink")?.getAttribute("title") || q(".playbackSoundBadge__titleLink span:last-child")?.textContent || "";
    const artist = q(".playbackSoundBadge__lightLink")?.getAttribute("title") || q(".playbackSoundBadge__lightLink")?.textContent || "";
    const artwork = q(".playbackSoundBadge span.sc-artwork")?.style?.backgroundImage?.replace(/^url\(["']?/, "").replace(/["']?\)$/, "") || "";
    const current = q(".playbackTimeline__timePassed span:last-child")?.textContent || "";
    const total = q(".playbackTimeline__duration span:last-child")?.textContent || "";
    return {
      title,
      artist,
      artwork,
      current,
      total,
      playing: isPlaying(),
      liked: isToggled(q(".playbackSoundBadge__like")),
      shuffled: isToggled(q(".playControls__shuffle")),
      repeating: isToggled(q(".playControls__repeat")),
      muted: isToggled(q(".volume__button")),
    };
  }

  const actions = {
    playPause: () => click(".playControls__play"),
    play: () => { if (!isPlaying()) click(".playControls__play"); },
    pause: () => { if (isPlaying()) click(".playControls__play"); },
    next: () => click(".playControls__next"),
    prev: () => click(".playControls__prev"),
    shuffle: () => click(".playControls__shuffle"),
    repeat: () => click(".playControls__repeat"),
    like: () => click(".playbackSoundBadge__like"),
    volumeUp: () => {
      const v = q(".volume");
      if (v) {
        v.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
        setTimeout(() => {
          const slider = q(".volume__sliderWrapper");
          if (!slider) return;
          const rect = slider.getBoundingClientRect();
          const y = rect.top + rect.height * 0.1;
          const x = rect.left + rect.width / 2;
          slider.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, clientX: x, clientY: y }));
          slider.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, clientX: x, clientY: y }));
        }, 120);
      }
    },
    volumeDown: () => {
      const v = q(".volume");
      if (v) {
        v.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
        setTimeout(() => {
          const slider = q(".volume__sliderWrapper");
          if (!slider) return;
          const rect = slider.getBoundingClientRect();
          const y = rect.top + rect.height * 0.9;
          const x = rect.left + rect.width / 2;
          slider.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, clientX: x, clientY: y }));
          slider.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, clientX: x, clientY: y }));
        }, 120);
      }
    },
    mute: () => click(".volume__button"),
    seek: (percent) => {
      const bar = q(".playbackTimeline__progressWrapper");
      if (!bar) return false;
      const rect = bar.getBoundingClientRect();
      const x = rect.left + rect.width * (percent / 100);
      const y = rect.top + rect.height / 2;
      ["mousedown", "mouseup", "click"].forEach((type) =>
        bar.dispatchEvent(new MouseEvent(type, { bubbles: true, clientX: x, clientY: y }))
      );
      return true;
    },
  };

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === "sc_action") {
      const fn = actions[msg.action];
      if (fn) fn(msg.value);
      // Krótka zwłoka - SoundCloud aktualizuje klasy/aria-pressed (np. serduszko
      // "polubione") z niewielkim opóźnieniem po kliknięciu, więc odczyt "na styk"
      // potrafi zwrócić jeszcze stary stan.
      setTimeout(() => sendResponse({ ok: true, info: getTrackInfo() }), 150);
      return true;
    } else if (msg.type === "sc_info") {
      sendResponse({ ok: true, info: getTrackInfo() });
    }
    return true;
  });

  // Push updates every 2s to background
  setInterval(() => {
    try {
      chrome.runtime.sendMessage({ type: "sc_update", info: getTrackInfo() });
    } catch (e) {}
  }, 2000);
})();
